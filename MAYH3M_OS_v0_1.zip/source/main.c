#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>

typedef enum {
    PAGE_HOME,
    PAGE_APPS,
    PAGE_GAMES,
    PAGE_SETTINGS
} Page;

static C2D_TextBuf textBuf;
static C2D_Text title;
static C2D_Text subtitle;
static C2D_Text apps;
static C2D_Text games;
static C2D_Text settings;
static C2D_Text status;
static C2D_Text hint;

static void textInit(C2D_Text* out, const char* value)
{
    C2D_TextParse(out, textBuf, value);
    C2D_TextOptimize(out);
}

static void textDraw(const C2D_Text* t, float x, float y, float scale, u32 color)
{
    C2D_DrawText(t, C2D_WithColor, x, y, 0.0f, scale, scale, color);
}

static void panel(float x, float y, float w, float h, bool selected)
{
    u32 fill = selected
        ? C2D_Color32(0, 150, 220, 255)
        : C2D_Color32(18, 25, 34, 255);

    C2D_DrawRectSolid(x, y, 0.0f, w, h, fill);
    C2D_DrawRectSolid(x, y, 0.1f, w, 2.0f,
                      C2D_Color32(0, 220, 255, 255));
}

static void drawHome(int selected)
{
    const u32 white = C2D_Color32(245, 250, 255, 255);
    const u32 cyan  = C2D_Color32(0, 220, 255, 255);

    C2D_DrawRectSolid(0, 0, 0, 400, 240, C2D_Color32(5, 8, 13, 255));
    C2D_DrawRectSolid(0, 0, 0.1f, 400, 4, cyan);

    textDraw(&title, 20, 16, 0.72f, white);
    textDraw(&subtitle, 22, 47, 0.38f, cyan);

    panel(22, 78, 108, 48, selected == 0);
    panel(146, 78, 108, 48, selected == 1);
    panel(270, 78, 108, 48, selected == 2);

    textDraw(&apps, 48, 94, 0.45f, white);
    textDraw(&games, 169, 94, 0.45f, white);
    textDraw(&settings, 283, 94, 0.40f, white);

    C2D_DrawRectSolid(22, 145, 356, 48, C2D_Color32(12, 17, 24, 255));
    textDraw(&status, 35, 160, 0.38f, cyan);

    textDraw(&hint, 22, 214, 0.34f, C2D_Color32(180, 195, 205, 255));
}

static void drawPage(const char* pageName, const char* message)
{
    C2D_Text heading;
    C2D_Text body;

    textInit(&heading, pageName);
    textInit(&body, message);

    C2D_DrawRectSolid(0, 0, 0, 400, 240, C2D_Color32(5, 8, 13, 255));
    C2D_DrawRectSolid(0, 0, 0.1f, 400, 4, C2D_Color32(0, 220, 255, 255));

    textDraw(&heading, 22, 18, 0.70f, C2D_Color32(245, 250, 255, 255));

    C2D_DrawRectSolid(22, 70, 356, 105, C2D_Color32(15, 21, 29, 255));
    textDraw(&body, 38, 88, 0.46f, C2D_Color32(220, 230, 240, 255));

    textDraw(&hint, 22, 214, 0.34f, C2D_Color32(180, 195, 205, 255));
    C2D_TextBufClear(textBuf);
}

int main(void)
{
    gfxInitDefault();

    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    C3D_RenderTarget* top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);

    textBuf = C2D_TextBufNew(4096);

    textInit(&title, "MAYH3M OS");
    textInit(&subtitle, "ELECTRIC MAYH3M  //  v0.1");
    textInit(&apps, "APPS");
    textInit(&games, "GAMES");
    textInit(&settings, "SETTINGS");
    textInit(&status, "SYSTEM ONLINE   |   UI MODE");
    textInit(&hint, "D-PAD: MOVE     A: SELECT     B: BACK");

    Page page = PAGE_HOME;
    int selected = 0;

    while (aptMainLoop())
    {
        hidScanInput();
        u32 down = hidKeysDown();

        if (page == PAGE_HOME)
        {
            if (down & KEY_LEFT)
                selected = (selected + 2) % 3;
            if (down & KEY_RIGHT)
                selected = (selected + 1) % 3;

            if (down & KEY_A)
            {
                if (selected == 0) page = PAGE_APPS;
                else if (selected == 1) page = PAGE_GAMES;
                else page = PAGE_SETTINGS;
            }
        }
        else if (down & KEY_B)
        {
            page = PAGE_HOME;
        }

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(top, C2D_Color32(5, 8, 13, 255));
        C2D_SceneBegin(top);

        if (page == PAGE_HOME)
            drawHome(selected);
        else if (page == PAGE_APPS)
            drawPage("APPS", "Calculator   Notes   Clock");
        else if (page == PAGE_GAMES)
            drawPage("GAMES", "MAYH3M games will live here.");
        else
            drawPage("SETTINGS", "MAYH3M OS settings will live here.");

        C3D_FrameEnd(0);
    }

    C2D_TextBufDelete(textBuf);
    C2D_Fini();
    C3D_Fini();
    gfxExit();

    return 0;
}
