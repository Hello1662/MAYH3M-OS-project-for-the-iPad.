# MAYH3M OS v0.1

A deliberately small graphical Nintendo 3DS homebrew prototype for the
Electric MAYH3M project.

## Goal

Get a stable graphical UI rendering on the New 3DS XL first.

This is **not** a firmware replacement. It is a normal `.3dsx` homebrew
application, so it does not need to modify NAND or replace Nintendo's
system software.

## Current UI

- MAYH3M OS home screen
- APPS / GAMES / SETTINGS pages
- D-pad navigation
- A = select
- B = back
- 2D Citro2D graphics
- Cyan/black MAYH3M visual style

## Build requirements

Install the normal devkitPro 3DS development environment:

- devkitARM
- libctru
- citro3d
- citro2d

Then run:

    make

The output should be:

    MAYH3M_OS.3dsx

## Put it on the 3DS

For Homebrew Launcher, a common location is:

    /3ds/MAYH3M_OS/MAYH3M_OS.3dsx

Launch it through your normal homebrew setup.

## Important

This project intentionally starts small. Do not replace firmware or
delete system titles while developing it.

If the UI renders correctly, the next versions can add the real Apps
screen, Calculator, Notes, Clock, Settings, touch controls, bottom dock,
and animations one feature at a time.
